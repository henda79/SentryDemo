﻿using Xamarin.Forms;

namespace SentryDemo
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
            throw null;
        }
    }
}
